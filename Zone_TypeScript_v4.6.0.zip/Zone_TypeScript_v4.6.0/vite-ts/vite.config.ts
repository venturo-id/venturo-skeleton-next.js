import path from 'path';
import react from '@vitejs/plugin-react';
import checker from 'vite-plugin-checker';
import { defineConfig, esmExternalRequirePlugin } from 'vite';

// ----------------------------------------------------------------------

const PORT = 8001;

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    checker({
      typescript: true,
      eslint: {
        lintCommand: 'eslint "./src/**/*.{js,jsx,ts,tsx}"',
      },
      overlay: {
        position: 'tl',
        initialIsOpen: false,
      },
    }),
    /**
     * VITE 8 FIX: Handles CommonJS variables (require/module)
     */
    esmExternalRequirePlugin({
      external: [
        // 'dashjs' (used by react-player)
        'dashjs',
      ],
    }),
  ],
  resolve: {
    alias: [
      {
        find: /^src(.+)/,
        replacement: path.resolve(process.cwd(), 'src/$1'),
      },
    ],
  },
  server: { port: PORT, host: true },
  preview: { port: PORT, host: true },
  build: {
    chunkSizeWarningLimit: 1000,
    rolldownOptions: {
      checks: {
        pluginTimings: false,
      },
    },
  },
});
